#include<stdio.h>
struct student
{
	int roll_no;
	char name[10];
	char address[50]; 
	
};
void main()
{
	struct student s1;
	printf("enter roll no");
	scanf("%d",&s1.roll_no);
	printf("enter name");
	scanf("%s",&s1.name);
	printf("enter address ");
	scanf("%s",&s1.address);



	
	printf("\n%d",s1.roll_no);
	
	printf("\n%s",s1.name);
	
	printf("\n%s",s1.address);
	



}
