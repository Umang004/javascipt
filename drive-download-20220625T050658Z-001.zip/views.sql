create table student
( Rno int,
  name varchar(50),
  branch  varchar(50),
  spi varchar(50),
  bklog int)

  insert  into student
  values(101,'raju','ce','8.80',0),
        (102,'amit','ce','2.20',3),
		(103,'sanjay','me','1.50',6),
         (104,'neha','ec','7.65',1),
		 (105,'meera','ee','5.52',2),
		 (106,'mahesh','ec','4.50',3)

		 create view personal
		 as 
		 select * from student
		 select * from personal

		 create view student_details
		 as 
		 select name,branch,spi from student

		 create view acadamic
		 as 
		 select Rno,name,branch from student

		 create view student_data
		 as
		 select * from student
		 where bklog>2

		 create view student_pattern
		 as
		 select Rno,name,branch from student
		 where name like'____' 
		 
		 insert into acadamic values(107,'meet','me')

		 update student_details
		 set branch='me'
		 where name='amit' and branch='ce'

		 delete  from acadamic
		 where  Rno=104

		 CREATE VIEW my
		 as
		 select * from student
		 where spi>9.5
		    
         create view bklog
		 as
		 select * from student
		 where bklog=0

		 select 
		    student_m.branch,
			avg(result.spi)
from result
inner join student_m
on student_m.rno=result.rno
group by branch 
order by result.spi