#include<stdio.h>
void main()
{
	char ch;
	printf("enter a char");
	scanf("%c",&ch);
	if(ch>='a'&& ch<='z')
	{
		printf("enter a character is small");

	} 
	else if(ch>='A'&&ch>='Z')
	{
		printf("enter a character is capital ");

	}
	else if(ch>='0'&& ch<='9' )
	{
		printf("enter a character is number");

	}
	else
	{
		printf("enter a character is special");	
	}
}		
