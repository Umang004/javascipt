#include<stdio.h>
void main()
{
	int n,sum=0,i=1;
	printf("enter a number= ");
	scanf("%d",&n);
	while(i<n)
	{	
		if(n%i==0)
		{
			sum=sum+i;
		}
		i++;
	}
	if(n==sum)
	{
		printf("given number is perfact");
	}
	else{
		printf("given nmuber is not perfact");
	}
	}

	



