#include<stdio.h>
void main()
{
	int n,x,i=1,sum=1;
	printf("enter n=" );
	scanf("%d",&n);
	printf("enter x=" );
	scanf("%d",&x);
	while(i<=n)
	{
		sum=(x*sum);
		
			

			i++;
			
	}	
		
					

	
	
	

	printf("%d",sum);
}