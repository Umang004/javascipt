#include<stdio.h>
void main()
{
	int no[10],pos=0,neg=0,zero=0,i;

	for(int i=0;i<10;++i);
	{
		if(no[i]>0)
		{
			pos+=1;
		}
		if(no[i]<0)
		{
			neg+=1;
		}
		if(no[i]==0)
		{
			zero+=1;

		}	
	}
	printf("\n positive=%d \n negative=%d \n zero=%d",pos,neg,zero)	;
}	