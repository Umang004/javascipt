insert into student_M values(101,'raju','ce')
insert into student_M values(102,'amit','ce')
insert into student_M	values(103,'sanjay','me')
insert into student_M	values(104,'neha','ec')
insert into student_M	values(105,'meera','ee')
insert into student_M	values(106,'mahesh','me')

insert into result values(101,8.8)
insert into result values(102,9.2)
insert into result values(103,7.6)
insert into result values(104,8.2)
insert into result values(105,7.0)
insert into result values(107,8.9)

insert into employee values('E01','tarun',null)

insert into employee values('E02','rohan','E02')

insert into employee values('E03','priya','E01')

insert into employee values('E04','milan','E03')

insert into employee values('E05','jay','E01')

insert into employee values('E06','anjana','E04')

Select
       student_m.rno,
	   student_m.name,
	   result.spi
from student_m
inner join result
on student_m.rno=result.rno
where branch<>'ec'




 