#include<stdio.h>
void main()
{
	int year;
	printf("enter your year=" );
	scanf("%d",%year);
	if(yr%4==0 && year%100!=0)
	{
		printf("a year is leap year");

	}
	else if(year%400==0)
	{
		printf("year is leap year");

	}
	else
	{
		printf("year is not a leap year");
	}
}		