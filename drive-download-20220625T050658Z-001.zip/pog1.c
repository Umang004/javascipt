#include<stdio.h>
void main()
{
	char ch;
	printf("enter ch");
	scanf("%c",&ch);
	printf("ASCII value=%d",ch);
}

