#include<stdio.h>
void main()
{
	int no[10]