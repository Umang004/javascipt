#include<stdio.h>
float interest(int,int,int);
void main()
{
	int p,r,n;
	float intr;
	printf("enter p=");
	scanf("%d",&p);
	printf("enter r=");
	scanf("%d",&r);
	printf("enter n=");
	scanf("%d",&n);
	intr=interest(p,r,n);
	printf("%f",intr);
}
float interest(int p,int r,int n)
{
	return (p*r*n)/100;
}


 