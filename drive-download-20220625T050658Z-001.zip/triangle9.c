#include<stdio.h>
void main()
{
	int a,b,c;
	printf("enter a=");
	scanf("%d",&a);
	printf("enter b=");
	scanf("%d",&b);
	printf("enter c=");
	scanf("%d",&c);
	if(a==b&&b==c) 
	{
		printf("\n equilateral." );
	}
		
		
	else if(a==b||b==c||c==a)
	{
		printf("\n isosclar.");
	}
	else if	((a*a)+(b*b)==(c*c)||(a*a)==(b*b)+(c*c)||(b*b)==(a*a)+(c*c))
	{
		printf("\n rightangle." );
	}
	else
	{
		printf("\n scale." );
	}	
}	

		
