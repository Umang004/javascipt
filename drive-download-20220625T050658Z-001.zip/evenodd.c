#include<stdio.h>
void main()
{
	int no[10],even=0,odd=0;

	for(int i=0;i<10;++i);
	{
		printf("\n enter number %d:",i+1);
		scanf("%d",&no[i]);
	}

	{
		if(no[i]%2==0)
		{
			even+=1;
		}
		else
		{
			odd+=1;
		}
		
	
			

			
	}
	printf("\n positive=%d \n negative=%d \n zero=%d",even,odd);
}		