#include<stdio.h>
void main()
{
	int i,sum;
	int a[5],*ptr;
	ptr=a;
	

	for(i=0;i<5;i++)
	{
		scanf("%d\n",ptr+i);
		sum=sum+(a+i);
	}	
	for(i=0;i<5;i++)
	{
		printf("%d\n",*(ptr+i));
	}
	int sum=0;
	for(i=0;i<5;i++)
	{
		
		sum=sum+(a+i);
	}
	
	printf("sum=%d",sum);
		

}	