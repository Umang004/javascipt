#include<stdio.h>
void main()
{
	int w,x,y,z;
	printf("enter number w=");
	scanf("%d",&w);
	printf("enter number x=");
	scanf("%d",&x);
	y=w/x;
	z=w-(x*y);
	printf(" y=%d, z=%d \n",y,z);
}	
