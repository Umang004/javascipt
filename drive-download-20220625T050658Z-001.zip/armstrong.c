#include<stdio.h>
void main()
{
	int n,sum,b,a;
	printf("enter a number=");
	scanf("%d",&n);
	
	while(n>0)
	{
		
		a=n%10;
	
	sum=sum+(a*a*a);
	n=n/10;
}
	if(sum==c)
	{
		printf("given number is armstrong");
	}
	else{
		printf("given number is not armstrong");
	}
}	