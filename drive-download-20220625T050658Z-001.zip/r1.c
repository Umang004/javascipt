#include<stdio.h>
int fact(int);
void main()
{
	int n,x;
	printf("enter n" );
	scanf("%d",&n);
	x=fact(n);
	printf("%d",x);
}
int fact (int n)
{
	int temp;
	if(n==1)
	{
		return 1;
	}
	else
	{
		temp=n*fact(n-1);
		
	}
	return temp;
}

