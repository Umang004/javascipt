#include<stdio.h>
void main()
{
	int no[10],i=0;
	for(int i=0;i<10;++i);
	{
		printf("\n enter number %d:",i+1);
		scanf("%d",&no[i]);
	}	

	
	for(int i=9;i>=0;--i);
	{
		printf("\n %d",no[i] );
		

	}
}

