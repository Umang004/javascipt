select 5*30 

select abs(-25),abs(25),abs(-50),abs(50)

select CEILING(25.2),CEILING(25.7),CEILING(-25.2)

select FLOOR(25.2),FLOOR(25.7),FLOOR(-25.2)

select 5%2 ,5%3

select power(3,2),power(4,3)

select sqrt(25),sqrt(30),sqrt(50)

select sqrt(5), sqrt(15), sqrt(25)

select pi()

select round(157.732,2),round(157.732,0),round(157.732,-2) 

select exp(2),exp(3)

select log10(5),log10(100)

select sin(3.1415),cos(3.1415),tan(3.1415)

select sign(-25),sign(0),sign(25)

select rand()