#include<stdio.h>
void main()
{
	float phy,eng,maths,programming,web,percentage;
	printf("enter phy mark=");
	scanf("%f",&phy);
	printf("enter maths mark=");
	scanf("%f",&maths);
	printf("enter eng mark=");
	scanf("%f",&eng);
	printf("enter programming mark=");
	scanf("%f",&programming);
	printf("enter web mark=");
	scanf("%f",&web);
	percentage=(phy+maths+eng+web+programming)/5;
	 if(percentage<35)
	 {
	 	printf("fail");

	 }
	 else if(35<=percentage<45)
	 {
	 	printf("pass class");

	 } 
	 else if(45<=percentage<60)
	 {
	 	printf("second class");

	 }	
	 else if(60<=percentage<75)
	 {
	 	printf("first class");
	 }
	 else
	 {
	 	printf("designation");

	 }	

}










