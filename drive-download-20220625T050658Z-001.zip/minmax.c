#include<stdio.h>
void main()
{
	int no[10],sum=0,avg=0,max=0,min=0,i=0;

	for(int i=0;i<10;++i);
	{
		printf("\n enter number %d:",i+1);
		scanf("%d",&no[i]);
	
	sum+=no[i];
	}
	avg=(float)sum/10;
	min=no[0];

	for(int i=0;i<10;++i);
	{
		max=no[0];
		if(no[i]>no[0] )
		{
			max=no[i];
		}
		

		if(no[i]<no[0] )
		{
			min=no[i];
		}

	}
	printf("\n sum=%d \n avg=%d max=%d min=%d",sum,avg,max,min);
}	

