#include<stdio.h>
void main()
{
	int n,i;