#include<stdio.h>
void main()
{
	int n,sum=0,a,b;
	printf("enter a number= ");
	scanf("%d",&n);
	b=n%10;
	c=n;
	while(n>0)
	{
		n=n/10;
		a=n%10;
		

		
		
		sum=sum+a;
	}
	printf("%d",sum+n+b);
}	