#include<stdio.h>
void main()
{
	int n,i=100,sum=0,a;
	printf("enter a number=");
	scanf("%d",&n);
	
	while(n>0)
	{
		a=n%10;
		n=n/10;
		sum=sum+(a*i);
		i=i/10;
	}
	printf("%d",sum);
}	