#include<stdio.h>
void main()
{
	int n,x,i=1,sum;
	printf("enter n=" );
	scanf("%d",&n);
	printf("enter x=" );
	scanf("%d",&x);
	while(i<=n)
	{
		sum!=x;
		i++;
	}	
	printf("%d",sum);
}	