#include<stdio.h>
void main()
{
	int n,i;
	printf("enter a number= ");
	scanf("%d",&n);
	while(i<=n)
	{
		if(n%1==0)
		{
			f++;
		}	

		i++;

	}
	if(f==2)
	{
		printf("number is prime");
	}
	else{
		printf("number is not prime");
	}	
		
			
		
	
		
		

