#include<stdio.h>
void main()
{
	int a,b,u;
	printf("enter number a=");
	scanf("%d",&a);
	printf("enter number b=");
	scanf("%d",&b);
	u=a;
	a=(a*b)/a;
	b=(b*u)/b;

	printf(" a=%d, b=%d \n",a,b);
}	
