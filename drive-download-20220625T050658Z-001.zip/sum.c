
#include<stdio.h>
float a(n);
void main()
{
	int i,n;
	float intr;
	printf("enter n=");
	scanf("%d",&n);