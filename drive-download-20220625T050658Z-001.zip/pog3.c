#include<stdio.h>
void main()
{
	int a,b;
	printf("enter number a=");
	scanf("%d",&a);
	printf("enter number b=");
	scanf("%d",&b);

	b=(b/a);
	a=(a*b);
	a=(a/b);

	

	printf(" a=%d, b=%d \n",a,b);
}	
