#include<stdio.h>
void main()
{
	int no[10],sum=0,high=0;

	for(int i=0;i<10;++i);
	{
		printf("\n enter number %d:",i+1);
		scanf("%d",&no[i]);
	
	sum+=no[i];
	}
	avg=(float)sum/10;
	min=no[0];

	for(int i=0;i<10;++i);
	{
		if(no[1]>avg)
		{
			high+=1;
		}
	}
	printf("\n higher nmubers %d",high);
}	