#include<stdio.h>
viod main()
{
	int h,m,s;
	printf("enter  s=");
	scanf("%d",&s);
	h=s/3600;
	m=s%3600;
	s=m%60;
	s=m/60;
	printf("%d:%d:%d",h,m,s);
}		

